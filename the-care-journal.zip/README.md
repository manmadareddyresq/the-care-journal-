# The Care Journal

Ready to deploy Next.js project.